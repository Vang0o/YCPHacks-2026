package com.mrglabs.labelcsv;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.time.LocalDate;

/**
 * MRG Label → CSV — 5-minute TRIAL version (Schneider Prize 2026).
 *
 * <p>What this program does RIGHT NOW:
 * <ol>
 *   <li>Lets you pick a label image (we do not read it yet)</li>
 *   <li>Shows 7 editable CSV fields (filled with demo data)</li>
 *   <li>Saves those fields as a .csv file you name</li>
 * </ol>
 *
 * <p>TODO (next step): call a small LOCAL AI model (Ollama + moondream on
 * 127.0.0.1:11434) to fill the fields from the image instead of demo values.
 *
 * <p>How to run from the project folder:
 * <pre>
 *   mvn -q compile exec:java
 * </pre>
 */
public class Main {

    // ---- the ONLY seven CSV columns we ever write ----
    private static final String[] COLUMNS = {
            "Sample ID",
            "Date Sampled",
            "Date Received",
            "Machine",
            "Component",
            "Serial Number",
            "Reference Lube"
    };

    // One text box per column so the user can edit before saving
    private final JTextField[] fields = new JTextField[COLUMNS.length];

    // Remembers which image the user picked (path shown in the window)
    private final JLabel imageLabel = new JLabel("No image selected yet.");

    /** Program starts here. */
    public static void main(String[] args) {
        // Swing must be created on the Event Dispatch Thread (Java GUI rule)
        SwingUtilities.invokeLater(() -> new Main().showWindow());
    }

    /** Build and show the simple window. */
    private void showWindow() {
        JFrame frame = new JFrame("MRG Label → CSV (trial)");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(640, 480);
        frame.setLocationByPlatform(true);

        // BorderLayout = north/south/east/west/center regions
        JPanel root = new JPanel(new BorderLayout(8, 8));
        root.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        // --- top: pick image ---
        JButton pickBtn = new JButton("1. Pick label image…");
        pickBtn.addActionListener(e -> pickImage(frame));
        JPanel top = new JPanel(new BorderLayout(8, 8));
        top.add(pickBtn, BorderLayout.WEST);
        top.add(imageLabel, BorderLayout.CENTER);
        root.add(top, BorderLayout.NORTH);

        // --- middle: 7 editable fields ---
        JPanel form = new JPanel(new GridLayout(COLUMNS.length, 2, 6, 6));
        for (int i = 0; i < COLUMNS.length; i++) {
            form.add(new JLabel(COLUMNS[i] + ":"));
            fields[i] = new JTextField();
            form.add(fields[i]);
        }
        root.add(form, BorderLayout.CENTER);

        // Fill demo / placeholder values so Save works even without OCR
        loadDemoRow();

        // --- bottom: save CSV ---
        JButton saveBtn = new JButton("2. Save CSV…");
        saveBtn.addActionListener(e -> saveCsv(frame));
        JLabel tip = new JLabel("Trial: demo fields are editable. Local AI OCR is TODO.");
        JPanel bottom = new JPanel(new BorderLayout(8, 8));
        bottom.add(saveBtn, BorderLayout.WEST);
        bottom.add(tip, BorderLayout.CENTER);
        root.add(bottom, BorderLayout.SOUTH);

        frame.setContentPane(root);
        frame.setVisible(true);
    }

    /**
     * Open a file picker. We only store the path for now.
     * TODO: send this image to local moondream via Ollama and fill fields.
     */
    private void pickImage(JFrame frame) {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Choose a sample-tube label photo");
        chooser.setFileFilter(new FileNameExtensionFilter(
                "Images", "png", "jpg", "jpeg", "gif", "bmp", "webp"));
        int result = chooser.showOpenDialog(frame);
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            imageLabel.setText("Image: " + file.getAbsolutePath());
            // Keep demo values so the trial always has something to save.
            // When OCR is wired, replace loadDemoRow() with real extraction here.
            JOptionPane.showMessageDialog(frame,
                    "Image selected.\nOCR is not wired in this trial — edit the demo fields, then Save CSV.\n\n"
                            + "TODO: local AI (Ollama moondream) will read this file later.",
                    "Trial mode",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /**
     * Hardcoded demo row (Small-tube style mapping) so judges can save a CSV now.
     * Empty cells stay empty strings — never invent Serial Number.
     */
    private void loadDemoRow() {
        // Sample ID = Circled Num + GS   (Small tube rule)
        fields[0].setText("1842 GS");
        // Date Sampled
        fields[1].setText("2026-10-28");
        // Date Received = today
        fields[2].setText(LocalDate.now().toString());
        // Machine = Equip ID
        fields[3].setText("EQ-7741");
        // Component = Sample Point
        fields[4].setText("GEARBOX-IN");
        // Serial Number = leave blank
        fields[5].setText("");
        // Reference Lube
        fields[6].setText("ISO-VG-220");
    }

    /**
     * Ask where to save, then write header + one data row (exactly 7 columns).
     */
    private void saveCsv(JFrame frame) {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Save CSV as…");
        chooser.setSelectedFile(new File("mrg-samples-trial.csv"));
        int result = chooser.showSaveDialog(frame);
        if (result != JFileChooser.APPROVE_OPTION) {
            return;
        }

        File out = chooser.getSelectedFile();
        // Make sure the name ends with .csv
        if (!out.getName().toLowerCase().endsWith(".csv")) {
            out = new File(out.getParentFile(), out.getName() + ".csv");
        }

        try (FileWriter writer = new FileWriter(out)) {
            // Header line
            writer.write(String.join(",", COLUMNS));
            writer.write("\n");
            // One data row — escape cells that contain commas/quotes
            for (int i = 0; i < fields.length; i++) {
                if (i > 0) {
                    writer.write(",");
                }
                writer.write(csvEscape(fields[i].getText()));
            }
            writer.write("\n");

            JOptionPane.showMessageDialog(frame,
                    "Saved:\n" + out.getAbsolutePath(),
                    "CSV saved",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame,
                    "Could not save CSV:\n" + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * CSV rule: if a value has a comma or quote, wrap it in quotes
     * and double any quotes inside.
     */
    private static String csvEscape(String value) {
        String v = value == null ? "" : value;
        if (v.contains(",") || v.contains("\"") || v.contains("\n")) {
            return "\"" + v.replace("\"", "\"\"") + "\"";
        }
        return v;
    }
}
