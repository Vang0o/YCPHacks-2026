# MRG Label → CSV (trial)

Schneider Prize 2026 · MRG Laboratories (Hammond Broiles)

Plain **Java 21** + **Maven** + **Swing** demo:

1. Pick a label image  
2. Edit the 7 CSV fields (demo values prefilled; OCR is TODO)  
3. Save a `.csv` with exactly those columns  

## Requirements

- Java 21+
- Maven 3.8+
- A display (Swing GUI)

## Run

```bash
cd mrg-label-csv
mvn -q compile exec:java
```

## CSV columns (exactly 7)

Sample ID, Date Sampled, Date Received, Machine, Component, Serial Number, Reference Lube

## Project layout

```
pom.xml
README.md
.gitignore
src/main/java/com/mrglabs/labelcsv/Main.java
```

## TODO

Wire a small **local** vision model (e.g. Ollama + `moondream` on `127.0.0.1:11434`) to fill fields from the picked image.
